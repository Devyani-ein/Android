/*package com.example.androidapplication1;

import android.content.Context;
import android.view.ViewGroup;

import androidx.annotation.NonNull;

import com.example.androidapplication1.RecycleView.Adapter;

import java.util.ArrayList;

public class CustomAdapter extends RecycleView.Adapter<CustomAdapter.> {
    ArrayList personNames;
    Context context;

    public CustomAdapter(Context context, ArrayList personNames) {
        this.context=context;
        this.personNames=personNames;
    }

    @NonNull
    @Override
  //  public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent,int ViewType)
    {

    }
*/
