package com.example.androidapplication1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;

public class Image extends AppCompatActivity {
    ImageView image1;
    Intent i;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_image);
        image1=(ImageView) findViewById(R.id.imageView2);

        Intent i = getIntent();
        String action = i.getAction();
        String type = i.getType();
        if(Intent.ACTION_SEND.equals(action) && type != null)
        {
            image1.setImageURI(i.getParcelableExtra(Intent.EXTRA_STREAM));
        }
    }
}