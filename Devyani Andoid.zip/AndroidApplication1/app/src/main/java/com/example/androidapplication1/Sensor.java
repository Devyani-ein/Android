package com.example.androidapplication1;

import androidx.appcompat.app.AppCompatActivity;

import android.hardware.SensorManager;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import java.util.List;

public class Sensor extends AppCompatActivity {
    
    TextView txt = null;
    private SensorManager mSensorManager;
    private Object TYPE_ALL;

    @Override
        protected void onCreate(Bundle savedInstanceState){
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_sensor);
            txt = (TextView) findViewById(R.id.t1);
            txt.setVisibility(View.GONE);
            mSensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
            List<android.hardware.Sensor> mList = mSensorManager.getSensorList((Integer) TYPE_ALL);
            for (int i = 0; i < mList.size(); i++) {
                txt.setVisibility(View.VISIBLE);
                txt.append("\n"+mList.get(i).getName());}
        }

    public class TYPE_ALL {
    }
}


