package com.example.androidapplication1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;

public class ImplicitActivity extends AppCompatActivity {
    Button implicit, implicit1;
    EditText text;
    ImageButton btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_implicit);
        setTitle("Intent Page");

        implicit = (Button) findViewById(R.id.button3);
        implicit1 = (Button) findViewById(R.id.button4);
        text = (EditText) findViewById(R.id.text1);
        btn = (ImageButton) findViewById(R.id.imageButton2);

        implicit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse("https://www.einfochips.com/"));
                startActivity(intent);
            }
        });

        implicit1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String text1 = "Hello Guys....!";
                Intent i = new Intent(Intent.ACTION_SEND);
                i.setType("text/plain");
                i.putExtra(Intent.EXTRA_TEXT, text1);
                startActivity(Intent.createChooser(i, "Suggest to Friends"));
                text.setText("");
            }
        });

        text.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String phone = "+917350015314";
                Intent intent = new Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", phone, null));
                startActivity(intent);
            }
        });
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String text = "Hello Devyani....!";
                Intent i = new Intent(Intent.ACTION_SEND);
                i.setType("text/plain");
                i.putExtra(Intent.EXTRA_TEXT, text);
                i.setPackage("com.whatsapp");
                startActivity(Intent.createChooser(i, "Suggest to Friends"));
            }
        });
    }
}