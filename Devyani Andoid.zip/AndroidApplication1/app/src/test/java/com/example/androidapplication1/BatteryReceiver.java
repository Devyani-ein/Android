package com.example.androidapplication1;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class BatteryReceiver {

}